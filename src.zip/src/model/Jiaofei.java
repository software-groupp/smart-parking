package model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

//缴费标准表
@Entity
@Table(name="t_Jiaofei")
public class Jiaofei implements Serializable{
	
	private static final long serialVersionUID = -117947798302585032L;

	private int id;//主键
	private double price;//费用（元/小时）
	private Date createtime;//添加时间
	private int jiaofeilock;//0表示未删除，1表示删除


	
	@Id
	@GeneratedValue
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}


	public int getJiaofeilock() {
		return jiaofeilock;
	}

	public void setJiaofeilock(int jiaofeilock) {
		this.jiaofeilock = jiaofeilock;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	
	
	
}
