package model;


import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

//停车记录
@Entity
@Table(name="t_Record")
public class Record {	

	@Id
	@GeneratedValue
	private int id;//主键
	
	@ManyToOne
	@JoinColumn(name="userid")
    private User user ;//关联车辆
	@ManyToOne
	@JoinColumn(name="lotid")
    private Lot lot ;//关联车位 
	@ManyToOne
	@JoinColumn(name="jiaofeiid")
    private Jiaofei jiaofei ;//关联缴费标准
	
	private String comDate;//日期
	private String comtime;//进入时间
	private String outime;//离开时间
	private int shichang;//收费时长（小时）
	private double number;//合计费用
	private String bianhao;//缴费单编号
	private String stauts;//缴费状态（等待缴费，已缴费）
	private Date createtime;//生成时间
	private int recordlock;//删除状态  0表示未删除 1表示已删除
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Lot getLot() {
		return lot;
	}

	public void setLot(Lot lot) {
		this.lot = lot;
	}

	public Jiaofei getJiaofei() {
		return jiaofei;
	}

	public void setJiaofei(Jiaofei jiaofei) {
		this.jiaofei = jiaofei;
	}

	public String getComtime() {
		return comtime;
	}

	public void setComtime(String comtime) {
		this.comtime = comtime;
	}

	public String getOutime() {
		return outime;
	}

	public void setOutime(String outime) {
		this.outime = outime;
	}

	public int getShichang() {
		return shichang;
	}

	public void setShichang(int shichang) {
		this.shichang = shichang;
	}

	public double getNumber() {
		return number;
	}

	public void setNumber(double number) {
		this.number = number;
	}

	public String getBianhao() {
		return bianhao;
	}

	public void setBianhao(String bianhao) {
		this.bianhao = bianhao;
	}

	public int getRecordlock() {
		return recordlock;
	}

	public void setRecordlock(int recordlock) {
		this.recordlock = recordlock;
	}

	public String getComDate() {
		return comDate;
	}

	public void setComDate(String comDate) {
		this.comDate = comDate;
	}

	public String getStauts() {
		return stauts;
	}

	public void setStauts(String stauts) {
		this.stauts = stauts;
	}

	
	
	

	
	

	
}
