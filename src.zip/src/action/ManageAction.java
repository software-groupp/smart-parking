package action;



import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.Jiaofei;
import model.Lot;
import model.Record;
import model.User;
import org.apache.struts2.ServletActionContext;
import util.Pager;
import util.Util;

import com.opensymphony.xwork2.ActionSupport;

import dao.JiaofeiDao;
import dao.LotDao;
import dao.RecordDao;
import dao.UserDao;



public class ManageAction extends ActionSupport{


	private static final long serialVersionUID = 1L;


	private String url="./";


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}

	private UserDao userDao;
	private LotDao lotDao;
	private RecordDao recordDao;
	private JiaofeiDao jiaofeiDao;


	public JiaofeiDao getJiaofeiDao() {
		return jiaofeiDao;
	}
	public void setJiaofeiDao(JiaofeiDao jiaofeiDao) {
		this.jiaofeiDao = jiaofeiDao;
	}


	public UserDao getUserDao() {
		return userDao;
	}


	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public LotDao getLotDao() {
		return lotDao;
	}


	public void setLotDao(LotDao lotDao) {
		this.lotDao = lotDao;
	}


	public RecordDao getRecordDao() {
		return recordDao;
	}


	public void setRecordDao(RecordDao recordDao) {
		this.recordDao = recordDao;
	}


	//用户登陆操作
	public void login() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		Integer role = Integer.parseInt(request.getParameter("role"));
		User user = userDao.selectBean(" where username='"+username+"' and password='"+password+"' and  userlock=0  and role="+role);
		if(user!=null){
			HttpSession session = request.getSession();
			session.setAttribute("user", user);
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('登陆成功');window.location.href='index.jsp'; </script>");
		}else{
			response.setCharacterEncoding("gbk");
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('用户名或者密码或者角色错误');window.location.href='login.jsp'; </script>");
		}

	}

	//用户退出操作
	public void loginout() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		session.removeAttribute("user");
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("gbk");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('退出成功');window.location.href='login.jsp'; </script>");
	}


	//跳转到修改密码页面
	public String passwordupdate(){
		this.setUrl("user/passwordupdate.jsp");
		return SUCCESS;
	}


	//修改密码操作
	public void passwordupdate2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String password1 = request.getParameter("password1");
		String password2 = request.getParameter("password2");
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("user");
		User bean = userDao.selectBean(" where username='"+user.getUsername()+"' and password='"+password1+"' ");
		if(bean!=null){
			bean.setPassword(password2);
			userDao.updateBean(bean);
			response.setCharacterEncoding("utf8");
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('操作成功'); </script>");
		}else{
			response.setCharacterEncoding("utf8");
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('原密码错误,修改失败!!');window.location.href='method!passwordupdate'; </script>");
		}		
	}




	//车辆页面
	public String userlist(){
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute("user");	
		String username = request.getParameter("username");
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		if(username!=null&&!"".equals(username)){
			sb.append("username like '%"+username+"%'");
			sb.append(" and ");
			request.setAttribute("username", username);
		}
		if(user.getRole()==1){
			sb.append(" userlock=0  and role=2 order by id desc");
		}
		if(user.getRole()==2){
			sb.append(" userlock=0  and id="+user.getId()+" order by id desc");
		}
		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		String where =sb.toString();
		long total = userDao.selectBeanCount(where.replaceAll("order by id desc", ""));
		List<User> list = userDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!userlist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		this.setUrl("user/userlist.jsp");
		return SUCCESS;
	}


	//跳转到添加车辆页面
	public String useradd(){
		this.setUrl("user/useradd.jsp");
		return SUCCESS;
	}

	//添加车辆操作
	public void useradd2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		response.setCharacterEncoding("utf8");
		String username = request.getParameter("username");
		String cname = request.getParameter("cname");
		String types = request.getParameter("types");
		User bean = userDao.selectBean(" where username='"+username+"' and userlock=0   ");
		if(bean==null){
			bean = new User();
			bean.setUsername(username);
			bean.setCname(cname);
			bean.setTypes(types);
			bean.setCreatetime(new Date());
			bean.setRole(2);
			bean.setPassword("123456");
			userDao.insertBean(bean);
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('提交成功');window.location.href='method!userlist'; </script>");
		}else{
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('提交失败，该车牌号已经存在');window.location.href='method!userlist'; </script>");
		}

	}

	//删除车辆操作
	public void userdelete() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String id = request.getParameter("id");
		User bean =userDao.selectBean(" where id= "+id);
		bean.setUserlock(1);
		userDao.insertBean(bean);
		response.setCharacterEncoding("utf8");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('提交成功');window.location.href='method!userlist'; </script>");

	}


	//跳转到更新车辆页面
	public String userupdate(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String id = request.getParameter("id");
		User bean =userDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		this.setUrl("user/userupdate.jsp");
		return SUCCESS;
	}


	//更新车辆操作
	public void userupdate2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String cname = request.getParameter("cname");
		String types = request.getParameter("types");
		String id = request.getParameter("id");
		User bean =userDao.selectBean(" where id= "+id);
		bean.setCname(cname);
		bean.setTypes(types);
		userDao.updateBean(bean);
		response.setCharacterEncoding("utf8");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('提交成功');window.location.href='method!userlist'; </script>");

	}



	//车位列表
	public String lotlist(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String number = request.getParameter("number");
		String stauts = request.getParameter("stauts");
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		if(number !=null &&!"".equals(number)){
			sb.append(" number like '%"+number+"%' ");
			sb.append(" and ");
			request.setAttribute("number", number);
		}
		if(stauts !=null &&!"".equals(stauts)){
			sb.append(" stauts like '%"+stauts+"%' ");
			sb.append(" and ");
			request.setAttribute("stauts", stauts);
		}
		sb.append(" deletestatus=0 order by id desc ");
		String where = sb.toString();
		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		long total = lotDao.selectBeanCount(where.replaceAll("order by id desc", ""));
		List<Lot> list = lotDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!lotlist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		this.setUrl("lot/lotlist.jsp");
		return SUCCESS;
	}


	//跳转到添加车位页面
	public String lotadd(){
		this.setUrl("lot/lotadd.jsp");
		return SUCCESS;
	}


	//添加车位操作
	public void lotadd2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String number = request.getParameter("number");
		String address = request.getParameter("address");
		Lot bean=lotDao.selectBean(" where number='"+number+"' and deletestatus=0 ");
		if(bean==null){
			bean = new Lot();
			bean.setNumber(number);
			bean.setAddress(address);
			bean.setStauts("空闲");
			bean.setCreatetime(new Date());
			lotDao.insertBean(bean);
			response.setCharacterEncoding("utf-8");response.setContentType("text/html; charset=utf-8");
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('提交成功');window.location.href='method!lotlist'; </script>");
		}else{
			response.setCharacterEncoding("utf-8");response.setContentType("text/html; charset=utf-8");
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('该编号，已经存在，请重新添加');window.location.href='method!lotlist'; </script>");
		}


	}



	//删除车位操作
	public void lotdelete() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String id = request.getParameter("id");
		Lot bean =lotDao.selectBean(" where id= "+id);
		bean.setDeletestatus(1);
		lotDao.updateBean(bean);
		response.setCharacterEncoding("utf-8");response.setContentType("text/html; charset=utf-8");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('提交成功');window.location.href='method!lotlist'; </script>");

	}

	//跳转到更新车位页面
	public String lotupdate(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String id = request.getParameter("id");
		Lot bean =lotDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		this.setUrl("lot/lotupdate.jsp");
		return SUCCESS;
	}


	//更新车位操作
	public void lotupdate2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String number = request.getParameter("number");
		String address = request.getParameter("address");
		String id = request.getParameter("id");
		Lot bean =lotDao.selectBean(" where id= "+id);
		bean.setNumber(number);
		bean.setAddress(address);
		bean.setCreatetime(new Date());
		lotDao.updateBean(bean);
		response.setCharacterEncoding("utf-8");response.setContentType("text/html; charset=utf-8");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('修改成功');window.location.href='method!lotlist'; </script>");

	}

	//缴费标准页面
	public String jiaofeilist(){
		HttpServletRequest request = ServletActionContext.getRequest();
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		sb.append(" jiaofeilock=0 order by id desc");
		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		String where =sb.toString();
		long total = jiaofeiDao.selectBeanCount(where.replaceAll("order by id desc", ""));
		List<Jiaofei> list = jiaofeiDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!jiaofeilist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		this.setUrl("jiaofei/jiaofeilist.jsp");
		return SUCCESS;
	}


	//跳转到添加缴费标准页面
	public String jiaofeiadd(){
		this.setUrl("jiaofei/jiaofeiadd.jsp");
		return SUCCESS;
	}


	//添加缴费标准操作
	public void jiaofeiadd2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		Double price =Double.parseDouble( request.getParameter("price"));
		Jiaofei bean=jiaofeiDao.selectBean(" where  jiaofeilock=0 ");
		if(bean==null){
			bean = new Jiaofei();
			bean.setPrice(price);
			bean.setCreatetime(new Date());
			jiaofeiDao.insertBean(bean);
			response.setCharacterEncoding("utf-8");response.setContentType("text/html; charset=utf-8");
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('添加成功');window.location.href='method!jiaofeilist'; </script>");	
		}else{
			response.setCharacterEncoding("utf-8");response.setContentType("text/html; charset=utf-8");
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('添加失败，标准已存在，请在列表页编辑');window.location.href='method!jiaofeilist'; </script>");	
		}   
	}


	//删除缴费标准操作
	public void jiaofeidelete() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String id = request.getParameter("id");
		Jiaofei  bean =jiaofeiDao.selectBean(" where id= "+id);
		bean.setJiaofeilock(1);
		jiaofeiDao.updateBean(bean);
		response.setCharacterEncoding("utf8");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('删除成功');window.location.href='method!jiaofeilist'; </script>");

	}


	//跳转到更新缴费标准页面
	public String jiaofeiupdate(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String id = request.getParameter("id");
		Jiaofei  bean =jiaofeiDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		this.setUrl("jiaofei/jiaofeiupdate.jsp");
		return SUCCESS;
	}


	//更新缴费标准操作
	public void jiaofeiupdate2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		Double price =Double.parseDouble( request.getParameter("price"));
		String id = request.getParameter("id");
		Jiaofei  bean =jiaofeiDao.selectBean(" where id= "+id);
		bean.setPrice(price);
		bean.setCreatetime(new Date());
		jiaofeiDao.updateBean(bean);
		response.setCharacterEncoding("utf-8");response.setContentType("text/html; charset=utf-8");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('修改成功');window.location.href='method!jiaofeilist'; </script>");

	}

	/********停车记录*******/
	//停车记录页面
	public String recordlist(){
		HttpServletRequest request = ServletActionContext.getRequest();
	    HttpSession session = request.getSession();
	    User user = (User)session.getAttribute("user");	
		String bianhao = request.getParameter("bianhao");
		String username = request.getParameter("username");
		String stauts = request.getParameter("stauts");
		StringBuffer sb = new StringBuffer();
		sb.append(" where ");
		if(bianhao !=null &&!"".equals(bianhao)){
			sb.append(" bianhao like '%"+bianhao+"%' ");
			sb.append(" and ");
			request.setAttribute("bianhao", bianhao);
		}
		if(username !=null &&!"".equals(username)){
			sb.append(" user.username like '%"+username+"%' ");
			sb.append(" and ");
			request.setAttribute("username", username);
		}
		if(stauts !=null &&!"".equals(stauts)){
			sb.append(" stauts like '%"+stauts+"%' ");
			sb.append(" and ");
			request.setAttribute("stauts", stauts);
		}
		if(user.getRole()==1){
			sb.append(" recordlock=0 order by id desc");
		}
		if(user.getRole()==2){
			sb.append(" recordlock=0 and stauts!=null and user="+user.getId()+" order by id desc");
		}
		int currentpage = 1;
		int pagesize = 10;
		if(request.getParameter("pagenum") != null){
			currentpage = Integer.parseInt(request.getParameter("pagenum"));
		}
		String where =sb.toString();
		long total = recordDao.selectBeanCount(where.replaceAll("order by id desc", ""));
		List<Record> list = recordDao.selectBeanList((currentpage-1)*pagesize, pagesize, where);
		request.setAttribute("list", list);
		String pagerinfo = Pager.getPagerNormal((int)total, pagesize, currentpage, "method!recordlist", "共有"+total+"条记录");
		request.setAttribute("pagerinfo", pagerinfo);
		this.setUrl("record/recordlist.jsp");
		return SUCCESS;
	}


	//跳转到进入登记页面
	public String recordadd(){
		HttpServletRequest request = ServletActionContext.getRequest();
		request.setAttribute("lotlist", lotDao.selectBeanList(0, 9999, " where stauts ='空闲'  and deletestatus=0"));
		request.setAttribute("jiaofeilist", jiaofeiDao.selectBeanList(0, 9999, " where  jiaofeilock=0 "));
		request.setAttribute("userlist", userDao.selectBeanList(0, 9999, " where role=2  and userlock=0"));
		this.setUrl("record/recordadd.jsp");
		return SUCCESS;
	}


	//添加进入登记操作
	public void recordadd2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String lot = request.getParameter("lot");
		String jiaofei = request.getParameter("jiaofei");
		String user = request.getParameter("user");
		String comtime = request.getParameter("comtime");

		Record bean = new Record();
		bean.setBianhao(new Date().getTime()+"");
		bean.setUser(userDao.selectBean(" where id="+user));
		bean.setLot(lotDao.selectBean(" where id="+lot));
		bean.setJiaofei(jiaofeiDao.selectBean(" where id="+jiaofei));
		bean.setComDate(Util.getTime3(new Date()));
		bean.setComtime(comtime);
		bean.setCreatetime(new Date());
		recordDao.insertBean(bean);
		Lot a=lotDao.selectBean(" where id="+bean.getLot().getId());
		a.setStauts("已满");
		lotDao.updateBean(a);
		response.setCharacterEncoding("utf-8");response.setContentType("text/html; charset=utf-8");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('添加成功');window.location.href='method!recordlist'; </script>");	

	}





	//跳转到离开登记页面
	public String recordupdate(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String id = request.getParameter("id");
		Record  bean =recordDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		this.setUrl("record/recordupdate.jsp");
		return SUCCESS;
	}


	//离开登记操作
	public void recordupdate2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		Integer shichang = Integer.parseInt(request.getParameter("shichang"));
		String outime = request.getParameter("outime");
		String id = request.getParameter("id");
		Record  bean =recordDao.selectBean(" where id= "+id);
		bean.setShichang(shichang);
		bean.setOutime(outime);
		bean.setStauts("等待缴费");
		bean.setNumber(bean.getShichang()*bean.getJiaofei().getPrice());//合计时长计算
		bean.setCreatetime(new Date());
		recordDao.updateBean(bean);
		Lot a=lotDao.selectBean(" where id="+bean.getLot().getId());
		a.setStauts("空闲");
		lotDao.updateBean(a);
		response.setCharacterEncoding("utf-8");response.setContentType("text/html; charset=utf-8");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('操作成功');window.location.href='method!recordlist'; </script>");

	}

	//删除停车记录操作
	public void recorddelete() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String id = request.getParameter("id");
		Record  bean =recordDao.selectBean(" where id= "+id);
		bean.setRecordlock(1);
		recordDao.insertBean(bean);
		response.setCharacterEncoding("utf8");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('删除成功');window.location.href='method!recordlist'; </script>");

	}
	
	//跳转到缴费页面
	public String pay(){
		HttpServletRequest request = ServletActionContext.getRequest();
		String id = request.getParameter("id");
		Record  bean =recordDao.selectBean(" where id= "+id);
		request.setAttribute("bean", bean);
		this.setUrl("record/pay.jsp");
		return SUCCESS;
	}
	
	//缴费支付操作
	public void pay2() throws IOException{
		HttpServletRequest request = ServletActionContext.getRequest();
		HttpServletResponse response = ServletActionContext.getResponse();
		String id = request.getParameter("id");
		Record  bean =recordDao.selectBean(" where id= "+id);
		bean.setStauts("已缴费");
		recordDao.updateBean(bean);
		response.setCharacterEncoding("utf-8");response.setContentType("text/html; charset=utf-8");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('支付成功');window.location.href='method!recordlist'; </script>");

	}
	
	
	
	

}
