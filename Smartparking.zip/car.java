 public class car{
 public String number; 
 public int inhour;   
 public int inminute;  
 public int insecond; 
 public int outhour;  
 public int outminute; 
 public int outsecond; 
 public int count; 
 public car link; 

 public car(String num){
  this.number=num;
  this.inhour=0;
  this.inminute=0;
  this.insecond=0;
  this.outhour=0;
  this.outminute=0;
  this.outsecond=0;
  int count=0;
  car link=null;
 }

public car(){
  this.number="";
  this.inhour=0;
  this.inminute=0;
  this.insecond=0;
  this.outhour=0;
  this.outminute=0;
  this.outsecond=0;
  int count=0;
  car link=null;
 }
 
  public car getLink(){
  return link;
 }

public void setLink(car n){
  link=n;
 }

public String getNum(){
  return  number;

}
 
}