import java.io.*;
import java.lang.*;


public class  DemoParking{
 public mylist parking;  //ͣ���� We first need to create the public classes separately
 public myQueue waiting;  //����
 public String x1;   //ѡ��
 public String x2;   //����ĳ��ƺ�
 public String x3;   //�����ĳ��ƺ�
/*So let's look at our program,
 * our program has the main program and the methods that we create,
 * the methods are in car, and we have the list and queue main programs in the demo
 *  so we first need to create the public class DemoParking
    And create them separately*/

   //���췽��then we are construction method
 public   DemoParking(){
   parking=new mylist();   //��ʼ��ջvoid InitStack
   waiting=new myQueue();   //��ʼ������queue
   x1="";
   x2="";
   x3="";
 }


     // ��Ա�������˵�Member method: menu
 public void menu(){        
  System.out.println("                                            ");
  System.out.println("                                            ");
     System.out.println("          Welcome to this parking lot                ");
  System.out.println("*********************************************");
  System.out.println("*   This parking lot charges 1yuan per second. There are 5 parking Spaces in the parking lot   *");
  System.out.println("*      Back up to 2 yuan at a time (no charge at least!)      *");
  System.out.println("*********************************************");
  System.out.println("        1:driven in");
  System.out.println("        2:driven out");
  System.out.println("        3:parking sitation");
  System.out.println("        4:quit");   //+++++++++++++++++++++++++++
  System.out.print("please chose:");
    
  try{
   BufferedReader keyin = new BufferedReader(
    new InputStreamReader(System.in));
  x1 = keyin.readLine();

   
  }
  catch (IOException e)
  {
   System.out.print("error");
  }
  choice();
  
  

 }

    //��Ա������ѡ��Member method: select
 public void choice(){
    if(x1.equals("1")){   //����1  ����Member method: select
    System.out.print("Please enter license plate No:");//�����복�ƺ�:
    try{
         BufferedReader keyin1 = new BufferedReader(
                new InputStreamReader(System.in));
      x2 =new String( keyin1.readLine());
    }
    catch (IOException e){
            System.out.print("error");
          }
     in(x2);          
     menu();
    }

    if(x1.equals("2")){   //����2  ����Input 2 out
     System.out.print("Please enter license plate No");//�����복�ƺ�:Please enter license plate No

    try{
         BufferedReader keyin1 = new BufferedReader(
                new InputStreamReader(System.in));
      x3 =new String( keyin1.readLine());
     }
     catch (IOException e){
            System.out.print("error");
           }
     out(x3);            
    }
    if(x1.equals("3")){   //����3��ѯ Input 3 query
     Allprint();
     menu();
    }
    if(x1.equals("4")){   //����4�˳� Enter 4 to exit
     
    }

    else{    //���벻���Ϲ涨 ���ز˵�Enter non - conforming return menu
     menu();
    }
 }


    //��Ա���������복Member method: drive in
 public void in(String value){
	  if (parking.getLength()<5){  //��ջ
	   parking.push(value);
	   System.out.println("*********************************************");
	   System.out.println("Your license plate number:"+parking.getTop1().number);
	   System.out.println("Entry time:"+parking.getTop1().inhour+":"+parking.getTop1().inminute

	+":"+parking.getTop1().insecond);
	   System.out.println("*********************************************");
	  }else{
	   waiting.insertcar(value);  //�����
	  }
	 }


    //��Ա������������Drive the car
 public void out(String value){
   int i=parking.getLength();
   int b=parking.getLength();
   //ֻ��ջ���г� ���ҵ�����Only a car in the stack was found
   if(waiting.getLength()==0){
    while(parking.getTop1().number.equals(value)==false){
     parking.pop();     //��ʼ����egin to reverse
     i--;
    }
    parking.pop2();  //���������� ����ջ2Get out of the car and go to stack 2
    System.out.println("*********************************************");
    System.out.println("         Your license plate number:"+parking.getTop2().number);
    System.out.println("          entry time:"+parking.getTop2().inhour+":"+parking.getTop2().inminute

+":"+parking.getTop2().insecond);
    System.out.println("         departure time:"+parking.getTop2().outhour+":"+parking.getTop2().outminute

+":"+parking.getTop2().outsecond);
    System.out.println("         Reverse the numbe:"+parking.getTop2().count);
    int s=((parking.getTop2().outhour-parking.getTop2().inhour)*60+parking.getTop2().outminute-

parking.getTop2().inminute)*60+parking.getTop2().outsecond-parking.getTop2().insecond-

2*parking.getTop2().count;
    System.out.println("         The cost of your:"+s+"Ԫ");
    System.out.println("         Welcome to come again!");
    System.out.println("*********************************************");
    parking.pop3();  //�ٴ�ջ2�е���And pop it out of stack 2
    if(i==b){
    }else{
     for(int n=i;n<b;n++){    //��������ջ1Reverse the car back to stack 1
      parking.push2();
     }
    }

   }else{
   //���ڶ��л�����ջ��It depends on whether it's in the queue or the stack
    while(parking.getNum(i).equals(value)==false){  //ջ
     i--;
     if(i==0){  //�������The inspection queue
      int a=waiting.getLength();
      while(waiting.locate(a).number.equals(value)==false){
       a--;
      }
       
      System.out.println("*********************************************");
      System.out.println("         Your license plate number:"+waiting.locate(a).number);
      System.out.println("        Welcome to come next time");
      System.out.println("*********************************************");
      waiting.delete(a);
      break;
       
     }
     
    }
    if(i>0){   //Ҫ�����ĳ���ջ��
     int c=i;
     for(;i<b;i++){
      parking.pop();
     }
     parking.pop2();
     System.out.println("*********************************************");
     System.out.println("         Your license plate number:"+parking.getTop2().number);
     System.out.println("         entry time:"+parking.getTop2().inhour+":"+parking.getTop2().inminute

+":"+parking.getTop2().insecond);
     System.out.println("         departure time:"+parking.getTop2().outhour+":"+parking.getTop2().outminute

+":"+parking.getTop2().outsecond);
     System.out.println("         Reverse the number:"+parking.getTop2().count);
     int s=((parking.getTop2().outhour-parking.getTop2().inhour)*60+parking.getTop2().outminute-

parking.getTop2().inminute)*60+parking.getTop2().outsecond-parking.getTop2().insecond-

2*parking.getTop2().count;
     if(s<0){
      s=0;  //��������Ϊ0
     }
     System.out.println("         The cost of your:"+s);  //����ʱ��������
     System.out.println("        Welcome to come again! ");
     System.out.println("*********************************************");
     parking.pop3();
     for(;c<b;c++){     
      parking.push2();
     }
     parking.push(waiting.getHeader().number);    //���еĵ�һ��Ԫ����ջThe first element of the queue is pushed
        waiting.delete(1);  //ɾ�����еĵ�һ��Ԫ��Delete the first element of the queue

    }
     }
 }

 //��ѯ��λ��� ����ջ�кͶ����е�Query for parking conditions including stack and queue
 public void Allprint(){
  System.out.println("*********************************************");
  System.out.println("In the parking lot:");
  parking.print();
  if(waiting.getLength()>0){
   System.out.println("waiting:");
   waiting.print();
  }
  System.out.println("*********************************************");
 }
  
  
public static void main(String[] args)throws IOException{ //apply����
 DemoParking demo=new DemoParking();
 demo.menu();

}

}
//And I'm going to show you how to do that
/*We have four functional AIDS
If you enter 1, you can query your entry time into the parking lot
If you type in 2 you can look up how long your car has been parked in the parking lot 
and how many times it has been backed up and how much you have to pay in the parking lot
If you enter 3 you can query the parking lot
Input 4 return*/