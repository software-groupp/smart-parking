import java.util.Date;

public class mylist{
 public int Length1;  
 public int Length2;
 public car[] carStark1;  
 public car[] carStark2; 

  public  mylist(){
  carStark1 =new car[5];  
  carStark2 =new car[5]; 
  Length1=0;
  Length2=0;
 }

public void push(String value){
  car newcar=new car(value);
  int n=Length1;
  carStark1[n]=newcar;
  Date now = new Date();  
  int hour = now.getHours();
  int minute = now.getMinutes();
  int second = now.getSeconds();
  carStark1[n].inhour=hour;
  carStark1[n].inminute=minute;
  carStark1[n].insecond=second;
  Length1++;
  
 }
 
 public void push2(){
  int n=Length1;
  carStark1[n]=getTop2();
  Length1++;
  Length2--;
  
 }
  public void pop(){
  car temp =getTop1();
  int n=Length2;
        carStark2[n]=temp;
  carStark2[n].count++;
     Length1--;
  Length2++;
 }
 
public void pop3(){
  Length2--;
 }

  public void pop2(){
  int n=Length1-1;
  Date now = new Date();
  int hour = now.getHours();
  int minute = now.getMinutes();
  int second = now.getSeconds();
  carStark1[n].outhour=hour;
  carStark1[n].outminute=minute;
  carStark1[n].outsecond=second;
  car temp = getTop1();
  carStark2[Length2]=temp;
  Length1--;
  Length2++;

 }
  
 public car getTop1(){
  return carStark1[Length1-1];
 }
public car getTop2(){
  return carStark2[Length2-1];
 }
public int getLength(){
  return Length1;
 }
    
 public String getNum(int i){
  return carStark1[i-1].number;
 }

public void print(){
  int i=0;
  for(i=0;i<Length1;i++){
   System.out.println(i+1+"�ų�λ��"+carStark1[i].number);
  }
}
}