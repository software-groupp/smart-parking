/**
 * Created by Thomas ji, 84051941.
 * Test by Thomas ji, 84051941.
 * Debugged by Thomas ji, 84051941.
 */
package model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

//用户(车辆)信息
@Entity
@Table(name="t_User")
public class User implements Serializable{
	
	private static final long serialVersionUID = -117947798302585032L;

	private int id;//主键
	private String username;//用户名(车牌号)
	private String password;//密码
	private String cname;//车辆品牌
	private String types;//车辆型号
	private Date createtime;//添加时间
	private int role;//权限，1管理员，2用户
	private int userlock;//0表示未删除，1表示删除


	
	@Id
	@GeneratedValue
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public int getRole() {
		return role;
	}

	public void setRole(int role) {
		this.role = role;
	}

	public int getUserlock() {
		return userlock;
	}

	public void setUserlock(int userlock) {
		this.userlock = userlock;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public String getTypes() {
		return types;
	}

	public void setTypes(String types) {
		this.types = types;
	}

	
	
	
}
