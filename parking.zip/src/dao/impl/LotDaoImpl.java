/**
 * Created by Alex, 99782827.
 * Test by Alex, 99782827.
 * Debugged by Alex, 99782827.
 */
package dao.impl;
import dao.LotDao;
import model.Lot;

import java.sql.SQLException;
import java.util.List;


import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;



public class LotDaoImpl extends HibernateDaoSupport implements LotDao {

	

	public void deleteBean(Lot bean) {
		this.getHibernateTemplate().delete(bean);
		
	}

	public void insertBean(Lot bean) {
		this.getHibernateTemplate().save(bean);
		
	}

	@SuppressWarnings("unchecked")
	public Lot selectBean(String where) {
		List<Lot> list = this.getHibernateTemplate().find("from Lot "+where);
		if(list.size()==0){
			return null;
		}
		return list.get(0);
	}

	public long selectBeanCount(final String where) {
		long count = (Long)this.getHibernateTemplate().find(" select count(*) from Lot  "+where).get(0);
		return count;
	}

	@SuppressWarnings("unchecked")
	public List<Lot> selectBeanList(final int start,final int limit,final String where) {
		return (List<Lot>)this.getHibernateTemplate().executeFind(new HibernateCallback(){

			public Object doInHibernate(final Session session) throws HibernateException, SQLException {
				List<Lot> list = session.createQuery(" from Lot"+where).setFirstResult(start).setMaxResults(limit).list();
				return list;
			}
		});
		
	}

	public void updateBean(Lot bean) {
		this.getHibernateTemplate().update(bean);
		
	}
	
	
	
	
	
	
	
}
